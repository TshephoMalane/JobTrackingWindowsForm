﻿using System;
using System.Linq;
using System.Windows.Forms;
using JobManagement.Data;
using JobTrackingApp.Models;

namespace JobTrackingApp
{
    public partial class EmployeeForm : Form
    {
        private ApplicationDbContext _context = new ApplicationDbContext();

        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            var employee = new Employee { EmployeeName = txtEmployeeName.Text };

            _context.Employees.Add(employee);
            _context.SaveChanges();
            MessageBox.Show("Employee added successfully!");
            LoadEmployees();
        }

        private void LoadEmployees()
        {
            dgvEmployees.DataSource = _context.Employees.ToList();
        }

        private void btnViewEmployees_Click(object sender, EventArgs e)
        {
            LoadEmployees();
        }
    }
}
