﻿using System;
using System.Linq;
using System.Windows.Forms;
using JobManagement.Data;
using JobTrackingApp.Models;

namespace JobTrackingApp
{
    public partial class TimeCardForm : Form
    {
        private ApplicationDbContext _context = new ApplicationDbContext();

        public TimeCardForm()
        {
            InitializeComponent();
            LoadEmployees();
            LoadJobs();
        }

        private void LoadEmployees()
        {
            cmbEmployee.DataSource = _context.Employees.ToList();
            cmbEmployee.DisplayMember = "EmployeeName";
            cmbEmployee.ValueMember = "Id";
        }

        private void LoadJobs()
        {
            cmbJob.DataSource = _context.Jobs.ToList();
            cmbJob.DisplayMember = "JobNo";
            cmbJob.ValueMember = "Id";
        }

        private void btnAddTimeCard_Click(object sender, EventArgs e)
        {
            var timeCard = new TimeCard
            {
                EmployeeId = (int)cmbEmployee.SelectedValue,
                JobId = (int)cmbJob.SelectedValue,
                WorkDate = dtpWorkDate.Value,
                HoursWorked = float.Parse(txtHoursWorked.Text)
            };

            _context.TimeCards.Add(timeCard);
            _context.SaveChanges();
            MessageBox.Show("Time card added successfully!");
            LoadTimeCards();
        }

        private void LoadTimeCards()
        {
            dgvTimeCards.DataSource = _context.TimeCards.ToList();
        }

        private void btnViewTimeCards_Click(object sender, EventArgs e)
        {
            LoadTimeCards();
        }
    }
}
