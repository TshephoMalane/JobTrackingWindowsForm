﻿namespace JobTrackingApp
{
    partial class TimeCardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbEmployee = new System.Windows.Forms.ComboBox();
            this.cmbJob = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpWorkDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHoursWorked = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddTimeCard = new System.Windows.Forms.Button();
            this.btnViewTimeCards = new System.Windows.Forms.Button();
            this.dgvTimeCards = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeCards)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEmployee
            // 
            this.cmbEmployee.FormattingEnabled = true;
            this.cmbEmployee.Location = new System.Drawing.Point(225, 29);
            this.cmbEmployee.Name = "cmbEmployee";
            this.cmbEmployee.Size = new System.Drawing.Size(121, 24);
            this.cmbEmployee.TabIndex = 0;
            // 
            // cmbJob
            // 
            this.cmbJob.FormattingEnabled = true;
            this.cmbJob.Location = new System.Drawing.Point(225, 83);
            this.cmbJob.Name = "cmbJob";
            this.cmbJob.Size = new System.Drawing.Size(121, 24);
            this.cmbJob.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(108, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Job";
            // 
            // dtpWorkDate
            // 
            this.dtpWorkDate.Location = new System.Drawing.Point(225, 132);
            this.dtpWorkDate.Name = "dtpWorkDate";
            this.dtpWorkDate.Size = new System.Drawing.Size(200, 22);
            this.dtpWorkDate.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Work Date";
            // 
            // txtHoursWorked
            // 
            this.txtHoursWorked.Location = new System.Drawing.Point(225, 183);
            this.txtHoursWorked.Name = "txtHoursWorked";
            this.txtHoursWorked.Size = new System.Drawing.Size(173, 22);
            this.txtHoursWorked.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(108, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Hours Worked";
            // 
            // btnAddTimeCard
            // 
            this.btnAddTimeCard.Location = new System.Drawing.Point(111, 242);
            this.btnAddTimeCard.Name = "btnAddTimeCard";
            this.btnAddTimeCard.Size = new System.Drawing.Size(91, 23);
            this.btnAddTimeCard.TabIndex = 8;
            this.btnAddTimeCard.Text = "Add Time Card";
            this.btnAddTimeCard.UseVisualStyleBackColor = true;
            // 
            // btnViewTimeCards
            // 
            this.btnViewTimeCards.Location = new System.Drawing.Point(283, 242);
            this.btnViewTimeCards.Name = "btnViewTimeCards";
            this.btnViewTimeCards.Size = new System.Drawing.Size(142, 23);
            this.btnViewTimeCards.TabIndex = 9;
            this.btnViewTimeCards.Text = "View Time Cards";
            this.btnViewTimeCards.UseVisualStyleBackColor = true;
            // 
            // dgvTimeCards
            // 
            this.dgvTimeCards.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTimeCards.Location = new System.Drawing.Point(106, 288);
            this.dgvTimeCards.Name = "dgvTimeCards";
            this.dgvTimeCards.RowHeadersWidth = 51;
            this.dgvTimeCards.RowTemplate.Height = 24;
            this.dgvTimeCards.Size = new System.Drawing.Size(240, 150);
            this.dgvTimeCards.TabIndex = 10;
            // 
            // TimeCardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 450);
            this.Controls.Add(this.dgvTimeCards);
            this.Controls.Add(this.btnViewTimeCards);
            this.Controls.Add(this.btnAddTimeCard);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtHoursWorked);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpWorkDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbJob);
            this.Controls.Add(this.cmbEmployee);
            this.Name = "TimeCardForm";
            this.Text = "TimeCardForm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeCards)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbEmployee;
        private System.Windows.Forms.ComboBox cmbJob;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpWorkDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHoursWorked;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddTimeCard;
        private System.Windows.Forms.Button btnViewTimeCards;
        private System.Windows.Forms.DataGridView dgvTimeCards;
    }
}