﻿using System;
using System.Linq;
using System.Windows.Forms;
using JobManagement.Data;
using JobTrackingApp.Models;

namespace JobManagementApp
{
    public partial class JobForm : Form
    {
        // Your database context (assuming you're using Entity Framework)
        private readonly ApplicationDbContext _context;

        public JobForm()
        {
            InitializeComponent();
            LoadJobTypes();
        }

        private void LoadJobTypes()
        {
            cmbJobType.Items.Add("Repair");
            cmbJobType.Items.Add("Support");
            cmbJobType.Items.Add("Warranty");
        }

        private void btnAddJob_Click(object sender, EventArgs e)
        {
            var job = new Job
            {
                JobNo = txtJobNo.Text,
                JobType = cmbJobType.SelectedItem.ToString(),
                JobDate = dtpJobDate.Value,
                CompanyName = txtCompany.Text,
                //ContactName = txtContact.Text,
                PhoneNumber = txtCompany.Text
            };

            _context.Jobs.Add(job);
            _context.SaveChanges();
            MessageBox.Show("Job added successfully!");
            LoadJobs();
        }

        private void LoadJobs()
        {
            dgvJobs.DataSource = _context.Jobs.ToList();
        }

        private void btnViewJobs_Click(object sender, EventArgs e)
        {
            LoadJobs();
        }
        private void txtCompany_TextChanged(object sender, EventArgs e)
        {
            // Add any logic for text change if needed
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Add any logic for text change if needed
        }

        private void JobForm_Load(object sender, EventArgs e)
        {

        }
    }
}