﻿using System;
using System.Data.Entity;
using JobTrackingApp.Models;

namespace JobManagement.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Job> Jobs { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<TimeCard> TimeCards { get; set; }


        public ApplicationDbContext() : base("Server=DESKTOP-15RBQI9;Database=JobTracking;Trusted_Connection=True") { }
    }


}
