﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobTrackingApp.Models
{
    public class Job
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(6)]
        public string JobNo { get; set; }

        [Required]
        public string JobType { get; set; }

        [Required]
        public DateTime JobDate { get; set; }

        [Required]
        public string CompanyName { get; set; }

        [Required]
        public string ContactName { get; set; }

        [Required, StringLength(15)]
        public string PhoneNumber { get; set; }
    }
}
