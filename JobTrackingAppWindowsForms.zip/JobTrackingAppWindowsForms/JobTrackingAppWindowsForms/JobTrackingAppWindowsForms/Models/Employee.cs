﻿using System.ComponentModel.DataAnnotations;

namespace JobTrackingApp.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string EmployeeName { get; set; }
    }
}
