﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobTrackingApp.Models
{
    public class TimeCard
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int EmployeeId { get; set; }

        [ForeignKey("EmployeeId")]
        public Employee Employee { get; set; }

        public int? JobId { get; set; } // Nullable
        [ForeignKey("JobId")]
        public Job Job { get; set; }

        [Required]
        public DateTime WorkDate { get; set; }

        [Required]
        public float HoursWorked { get; set; }
    }
}
