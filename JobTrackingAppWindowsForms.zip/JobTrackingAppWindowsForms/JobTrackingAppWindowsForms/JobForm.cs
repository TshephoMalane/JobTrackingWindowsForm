﻿using System;
using System.Linq;
using System.Windows.Forms;
using JobManagement.Data;

namespace JobManagementApp
{
    public partial class JobForm : Form
    {
        // Your database context (assuming you're using Entity Framework)
        private readonly ApplicationDbContext _context;

        public JobForm()
        {
            InitializeComponent();
            _context = new ApplicationDbContext(); // Initialize the context for DB
        }

        public JobForm(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }

        private void JobForm_Load(object sender, EventArgs e)
        {
            // Here, you can add any initialization logic you need when the form loads.
        }

        // Controls - This would typically be auto-generated in the Designer.cs file, but we're adding the controls here.
        private ComboBox cboJobType;
        private TextBox txtClientName;
        private TextBox txtClientPhone;
        private TextBox txtClientContact;
        private DateTimePicker dtpDate;
        private Button btnSaveJob;
        private ApplicationDbContext applicationDbContext;

     
        private void BtnSaveJob_Click(object sender, EventArgs e)
        {
            // Validation (Optional but recommended)
            if (string.IsNullOrEmpty(txtClientName.Text) || string.IsNullOrEmpty(txtClientPhone.Text))
            {
                MessageBox.Show("Client Name and Phone are required fields.");
                return;
            }

            // Get the selected Job Type and generate a Job Number (e.g., "R00001")
            string jobType = cboJobType.SelectedItem.ToString();
            string jobNo = jobType.Substring(0, 1) + (_context.Jobs.Count() + 1).ToString("D5");

            // Get other job details
            string clientName = txtClientName.Text;
            string clientPhone = txtClientPhone.Text;
            string clientContact = txtClientContact.Text;

            // Create a new Job object
            var job = new Job
            {
                JobNo = jobNo,
                JobType = jobType,
                Date = dtpDate.Value,
                ClientName = clientName,
                ClientPhone = clientPhone,
                ClientContact = clientContact
            };

            // Add the job to the DbContext and save changes
            _context.Jobs.Add(job);
            _context.SaveChanges();

            // Show success message
            MessageBox.Show("Job saved successfully!");

            // Optionally, clear the form after saving
            ClearForm();
        }

        // Method to clear the form after saving
        private void ClearForm()
        {
            cboJobType.SelectedIndex = -1;
            txtClientName.Clear();
            txtClientPhone.Clear();
            txtClientContact.Clear();
            dtpDate.Value = DateTime.Now;
        }

        private void btnSaveJob_Click(object sender, EventArgs e)
        {
            string jobType = cboJobType.SelectedItem.ToString();
            string jobNo = jobType.Substring(0, 1) + (_context.Jobs.Count() + 1).ToString("D5");
            string clientName = txtClientName.Text;
            string clientPhone = txtClientPhone.Text;
            string clientContact = txtClientContact.Text;

            var job = new Job
            {
                JobNo = jobNo,
                JobType = jobType,
                Date = dtpDate.Value,
                ClientName = clientName,
                ClientPhone = clientPhone,
                ClientContact = clientContact
            };

            _context.Jobs.Add(job);
            _context.SaveChanges();

            MessageBox.Show("Job saved successfully!");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
