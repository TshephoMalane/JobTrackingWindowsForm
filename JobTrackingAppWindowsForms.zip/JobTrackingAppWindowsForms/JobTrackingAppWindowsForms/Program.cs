﻿using JobManagement.Data; 
using System;
using System.Linq;
using System.Data.Entity;  

class Program
{
    static void Main(string[] args)
    {
        
        using (var context = new ApplicationDbContext())
        {

          
            context.SaveChanges();
            Console.WriteLine("New job added to the database.");
        }
    }
}
