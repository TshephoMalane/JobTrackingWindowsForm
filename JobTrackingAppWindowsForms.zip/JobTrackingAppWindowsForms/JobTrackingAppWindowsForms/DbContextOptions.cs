﻿namespace JobManagement.Data
{
    public class DbContextOptions<T>
    {
    }
}