﻿using System;
using System.Data.Entity; 

namespace JobManagement.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Job> Jobs { get; set; }
        public DbSet<TimeCard> TimeCards { get; set; }

      
        public ApplicationDbContext() : base("Server=localhost;Database=JobTracking;Trusted_Connection=True") { }
    }

    
    public class Job
    {
        public string JobNo { get; set; }
        public string JobType { get; set; }
        public DateTime Date { get; set; }
        public string ClientName { get; set; }
        public string ClientPhone { get; set; }
        public string ClientContact { get; set; }
    }

    public class TimeCard
    {
        public int TimeCardId { get; set; }
        public string JobNo { get; set; }
        public string EmployeeName { get; set; }
        public DateTime DateWorked { get; set; }
        public decimal HoursWorked { get; set; }
    }
}
