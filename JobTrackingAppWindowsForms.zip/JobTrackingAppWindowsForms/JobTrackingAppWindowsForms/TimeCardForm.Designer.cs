﻿namespace JobTrackingAppWindowsForms
{
    partial class TimeCardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboJob = new System.Windows.Forms.ComboBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.dtpDateWorked = new System.Windows.Forms.DateTimePicker();
            this.txtHoursWorked = new System.Windows.Forms.TextBox();
            this.btnSaveTimeCard = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cboJob
            // 
            this.cboJob.FormattingEnabled = true;
            this.cboJob.Location = new System.Drawing.Point(299, 72);
            this.cboJob.Name = "cboJob";
            this.cboJob.Size = new System.Drawing.Size(121, 24);
            this.cboJob.TabIndex = 0;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(486, 72);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(100, 22);
            this.txtEmployeeName.TabIndex = 1;
            // 
            // dtpDateWorked
            // 
            this.dtpDateWorked.Location = new System.Drawing.Point(286, 150);
            this.dtpDateWorked.Name = "dtpDateWorked";
            this.dtpDateWorked.Size = new System.Drawing.Size(200, 22);
            this.dtpDateWorked.TabIndex = 2;
            // 
            // txtHoursWorked
            // 
            this.txtHoursWorked.Location = new System.Drawing.Point(574, 150);
            this.txtHoursWorked.Name = "txtHoursWorked";
            this.txtHoursWorked.Size = new System.Drawing.Size(100, 22);
            this.txtHoursWorked.TabIndex = 3;
            // 
            // btnSaveTimeCard
            // 
            this.btnSaveTimeCard.Location = new System.Drawing.Point(410, 229);
            this.btnSaveTimeCard.Name = "btnSaveTimeCard";
            this.btnSaveTimeCard.Size = new System.Drawing.Size(75, 23);
            this.btnSaveTimeCard.TabIndex = 4;
            this.btnSaveTimeCard.Text = "button1";
            this.btnSaveTimeCard.UseVisualStyleBackColor = true;
            // 
            // TimeCardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 450);
            this.Controls.Add(this.btnSaveTimeCard);
            this.Controls.Add(this.txtHoursWorked);
            this.Controls.Add(this.dtpDateWorked);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.cboJob);
            this.Name = "TimeCardForm";
            this.Text = "TimeCardForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboJob;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.DateTimePicker dtpDateWorked;
        private System.Windows.Forms.TextBox txtHoursWorked;
        private System.Windows.Forms.Button btnSaveTimeCard;
    }
}