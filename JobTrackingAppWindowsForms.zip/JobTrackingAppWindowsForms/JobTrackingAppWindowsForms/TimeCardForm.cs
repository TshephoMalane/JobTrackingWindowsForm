﻿using JobManagement.Data;  
using System;
using System.Linq;
using System.Windows.Forms;

namespace JobTrackingAppWindowsForms
{
    public partial class TimeCardForm : Form
    {
        private readonly ApplicationDbContext _context;

        public TimeCardForm()
        {
            InitializeComponent();

      
            _context = new ApplicationDbContext();
        }

        private void btnSaveTimeCard_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (string.IsNullOrWhiteSpace(txtEmployeeName.Text) ||
                    string.IsNullOrWhiteSpace(txtHoursWorked.Text) ||
                    !decimal.TryParse(txtHoursWorked.Text, out decimal hoursWorked) ||
                    hoursWorked <= 0)
                {
                    MessageBox.Show("Please fill in all fields correctly.");
                    return;
                }

                
                var timeCard = new TimeCard
                {
                    JobNo = cboJob.SelectedItem.ToString(),
                    EmployeeName = txtEmployeeName.Text,
                    DateWorked = dtpDateWorked.Value,
                    HoursWorked = hoursWorked
                };

             
                _context.TimeCards.Add(timeCard);

                
                _context.SaveChanges();

                MessageBox.Show("Time card saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        
 
        }
    }
}
