﻿namespace JobManagementApp
{
    partial class JobForm
    {
       
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

 
        private void InitializeComponent()
        {
            this.comboBox_cboJobType = new System.Windows.Forms.ComboBox();
            this.textBox1_txtClientName = new System.Windows.Forms.TextBox();
            this.textBox1_txtClientPhone = new System.Windows.Forms.TextBox();
            this.textBox1_txtClientContact = new System.Windows.Forms.TextBox();
            this.dateTimePicker1_dtpDate = new System.Windows.Forms.DateTimePicker();
            this.button2_btnSaveJob = new System.Windows.Forms.Button();
            this.SuspendLayout();
       
            this.comboBox_cboJobType.FormattingEnabled = true;
            this.comboBox_cboJobType.Location = new System.Drawing.Point(312, 75);
            this.comboBox_cboJobType.Name = "comboBox_cboJobType";
            this.comboBox_cboJobType.Size = new System.Drawing.Size(121, 24);
            this.comboBox_cboJobType.TabIndex = 0;
            this.comboBox_cboJobType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
          
            this.textBox1_txtClientName.Location = new System.Drawing.Point(477, 77);
            this.textBox1_txtClientName.Name = "textBox1_txtClientName";
            this.textBox1_txtClientName.Size = new System.Drawing.Size(100, 22);
            this.textBox1_txtClientName.TabIndex = 1;
            this.textBox1_txtClientName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            
            this.textBox1_txtClientPhone.Location = new System.Drawing.Point(608, 77);
            this.textBox1_txtClientPhone.Name = "textBox1_txtClientPhone";
            this.textBox1_txtClientPhone.Size = new System.Drawing.Size(100, 22);
            this.textBox1_txtClientPhone.TabIndex = 2;
           
            this.textBox1_txtClientContact.Location = new System.Drawing.Point(728, 75);
            this.textBox1_txtClientContact.Name = "textBox1_txtClientContact";
            this.textBox1_txtClientContact.Size = new System.Drawing.Size(100, 22);
            this.textBox1_txtClientContact.TabIndex = 3;
           
            this.dateTimePicker1_dtpDate.Location = new System.Drawing.Point(312, 139);
            this.dateTimePicker1_dtpDate.Name = "dateTimePicker1_dtpDate";
            this.dateTimePicker1_dtpDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1_dtpDate.TabIndex = 4;
           
            this.button2_btnSaveJob.Location = new System.Drawing.Point(663, 139);
            this.button2_btnSaveJob.Name = "button2_btnSaveJob";
            this.button2_btnSaveJob.Size = new System.Drawing.Size(75, 23);
            this.button2_btnSaveJob.TabIndex = 6;
            this.button2_btnSaveJob.Text = "button2";
            this.button2_btnSaveJob.UseVisualStyleBackColor = true;
            
            this.ClientSize = new System.Drawing.Size(1103, 253);
            this.Controls.Add(this.button2_btnSaveJob);
            this.Controls.Add(this.dateTimePicker1_dtpDate);
            this.Controls.Add(this.textBox1_txtClientContact);
            this.Controls.Add(this.textBox1_txtClientPhone);
            this.Controls.Add(this.textBox1_txtClientName);
            this.Controls.Add(this.comboBox_cboJobType);
            this.Name = "JobForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label_label1;
        private System.Windows.Forms.ComboBox comboBox_cboJobType;
        private System.Windows.Forms.TextBox textBox1_txtClientName;
        private System.Windows.Forms.TextBox textBox1_txtClientPhone;
        private System.Windows.Forms.TextBox textBox1_txtClientContact;
        private System.Windows.Forms.DateTimePicker dateTimePicker1_dtpDate;
        private System.Windows.Forms.Button button2_btnSaveJob;
    }
}